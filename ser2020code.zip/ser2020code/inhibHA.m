
function a=  inhibHA(b);

%b = gha*;


 a = 1- (0)*(b - .6947);  %5
 
  end 